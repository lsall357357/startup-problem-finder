# Pitch-Deck Problem-Location Rubric

Use this reference to locate where a pitch deck or fundraising document blocks
understanding. Do not score the deck, force a fixed slide order, compare it with
famous decks, or decide whether it is ready to send.

## Evidence Labels

Classify each important claim internally as:

- stated and supported
- stated but unsupported
- stated but unclear
- internally inconsistent
- missing from the material
- unknown about the business itself

Keep "the deck does not explain it" separate from "the business has not solved
it." Escalate from the first to the second only when evidence supports that
conclusion.

## Opening And Project Definition

Check whether an investor can quickly understand:

- what the company currently delivers
- who uses it
- the concrete scenario
- the problem being addressed
- the current stage

Common blockers include a slogan replacing the product, a category label
replacing the problem, too many target users, or long-term vision appearing
before the current product is visible.

## Problem And User

Check whether the material distinguishes:

- user, buyer, payer, and decision maker
- frequent pain, high-value infrequent pain, and minor inconvenience
- observed behavior and founder assumption
- current alternatives and the cost of doing nothing

Look for user descriptions that are demographic but not behavioral, broad
scenario lists, unsupported frequency claims, or a problem that only exists
after accepting the proposed solution.

## Product And Delivery

Check:

- current product boundary
- actual workflow from entry to delivered result
- technology or operating capability that matters
- manual work hidden behind software claims
- dependencies, constraints, and failure cases
- what exists today versus roadmap items

Do not treat a prototype, demo, patent, model, or feature list as proof of
repeatable delivery.

## Validation

Identify the strongest available evidence and its limit:

- interviews and expressed interest
- prototype tests
- active use and retention
- pilots and paid pilots
- orders and revenue
- repeat purchase or expansion
- channel or partnership commitments

Check sample definition, time period, denominator, cohort consistency, and
whether the metric supports the claim attached to it. Do not invent benchmarks.

## Business Model

Set the standard by the project's stage and what the deck claims. At the idea
or early prototype stage, the absence of a formed business model alone is not
a BP weakness. Treat proposed transactions as hypotheses. If the deck says
the model works, forecasts revenue, or relies on commercialization to justify
the round, check the assumptions and evidence it presents for that claim.

Check which of these details matter to the claim and whether the deck makes
them clear:

- who pays
- what the payer buys
- pricing or value-measure logic
- revenue form and primary path
- delivery cost and repeatability
- procurement, sales, channel, or payment constraints

Mark future advertising, marketplace, data, ecosystem, and cross-sell revenue
as hypotheses unless there is evidence.

## Market And Competition

Check whether the market claim matches the actual product, geography, customer,
and price. Separate source data from founder calculations.

Large market numbers, policy momentum, category growth, and industry adoption
statistics can support the opportunity background. They do not prove the
project has captured demand. Treat them as context, not company evidence.

When a deck uses market size as traction, flag the gap directly: the data shows
that a market may exist, but it does not show this project has users, orders,
retention, paid pilots, channel access, delivery repeatability, or pricing
power.

Competition should include direct products, adjacent products, manual work,
internal teams, and doing nothing. Flag feature matrices that use self-selected
dimensions or ignore stronger substitutes.

## Team

Check whether claimed experience directly supports the project's current hard
problems. Distinguish full-time members, advisers, contractors, and partners.
Flag missing ownership of critical functions and prestige claims without
operating relevance.

## Fundraising Story

Check whether current evidence, current constraint, use of funds, next
milestone, and the next financing case connect. Flag department budgets without
milestones, round labels used as maturity evidence, and multiple unrelated uses
of funds.

## Consistency Pass

Cross-check:

- user definitions across slides
- product boundary across slides
- market size against pricing and customer count
- revenue against customer and contract claims
- team count against operating plan
- use of funds against milestone and hiring plan
- dates, units, currencies, and time periods

### Final Finding Checks

Once the findings are drafted, verify the exact claims behind the selected main
BP issue and any limitation in the value-anchor judgment. For each, identify
the product or subject, its stage, and any relevant scope or metric definition.
Look through the submitted material for details that clarify, qualify, or
contradict the finding. Check nearby labels, captions, footnotes, text inside
figures, and relevant passages on other pages or in appendices. Reopen the
relevant original page images when extraction is unreliable. If a relevant
detail remains unreadable, state the judgment it limits.

- **Main BP issue.** Withdraw a criticism the material already answers. If the
  explanation is present but difficult to find, identify where it appears and
  how its placement affects understanding. For a genuine conflict, identify
  both statements and check that they refer to the same scope. When a plan or
  forecast is already explained, identify any evidence or assumptions needed
  to support it. If the selected issue changes, compare the supported findings
  again and choose the one that most affects the reader's judgment.
- **Value-anchor limitation.** Verify the specific gap named after the clarity
  judgment. Check whether the material already explains the user, use case,
  usage steps, or delivered result in question. Base this judgment on the
  relevant product and stage. Check that the overview, overall assessment,
  value-anchor judgment, and fundraising story use the same product boundaries
  and interpret the same claims consistently.

## User-Facing Output

For each important blocker, state:

1. what the material currently communicates
2. where understanding stops
3. whether the issue is missing expression, missing evidence, contradiction, or
   an unknown business fact
4. what needs verification

Do not write replacement slide copy.
